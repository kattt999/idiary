<!--
 * @Author: liziwei01
 * @Date: 2022-03-03 16:25:21
 * @LastEditors: liziwei01
 * @LastEditTime: 2022-03-03 16:30:50
 * @Description: file content
-->
# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| > 0.0   | havn't support any safety updates     |

## Reporting a Vulnerability

Please reach us by 118010160@link.cuhk.edu.cn
