<!--
 * @Author: liziwei01
 * @Date: 2022-03-03 15:17:00
 * @LastEditors: liziwei01
 * @LastEditTime: 2022-03-03 16:32:12
 * @Description: file content
-->
# csc4001-idiary-app

[![standard-readme compliant](https://img.shields.io/badge/readme%20style-standard-brightgreen.svg?style=flat-square)](https://github.com/RichardLitt/standard-readme)

This is a school project written by Li, Yi, Wu, Zhang from CUHK(SZ)