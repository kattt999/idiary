# csc4001-idiary-app


### React: https://reactjs.org/  
### Bootstrap: https://getbootstrap.com/
### Font-awesome: https://fontawesome.com/
### react-router: https://reactrouterdotcom.fly.dev/docs/en/v6
### JSONplaceholder: http://jsonplaceholder.typicode.com/
### Axios: https://www.axios-http.cn/docs/intro
### React-Toastify: https://fkhadra.github.io/react-toastify/installation
### Sentry: https://docs.sentry.io/platforms/javascript/guides/react/usage/