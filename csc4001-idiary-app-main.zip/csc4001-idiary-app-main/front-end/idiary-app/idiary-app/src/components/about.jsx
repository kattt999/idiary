import React from "react";

const About = () => {
  return <h1>About iDiary</h1>;
};

export default About;
