import React from "react";

const PersonalCenter = () => {
  return <h1>Personal Center</h1>;
};

export default PersonalCenter;
