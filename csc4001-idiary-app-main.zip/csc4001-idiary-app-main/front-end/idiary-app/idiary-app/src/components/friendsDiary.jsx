const FriendsDiary = () => {
  return <h1>Friends' Diary</h1>;
};

export default FriendsDiary;
