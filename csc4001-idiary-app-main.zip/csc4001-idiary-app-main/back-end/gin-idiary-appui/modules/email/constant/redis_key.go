/*
 * @Author: liziwei01
 * @Date: 2022-04-12 13:17:07
 * @LastEditors: liziwei01
 * @LastEditTime: 2022-04-12 14:03:36
 * @Description: file content
 */
package constant

const (
	// 验证码邮件缓存 key
	CACHED_USER_EMAIL = "str:email:verification_code_to:%s"
)
