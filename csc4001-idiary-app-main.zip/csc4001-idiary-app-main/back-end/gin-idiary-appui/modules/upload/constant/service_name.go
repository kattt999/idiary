/*
 * @Author: liziwei01
 * @Date: 2022-03-03 16:16:57
 * @LastEditors: liziwei01
 * @LastEditTime: 2022-04-12 15:14:34
 * @Description: file content
 */

package constant

const (
	// oss service conf name
	SERVICE_CONF_OSS_IDIARY = "oss_idiary_image"
)
