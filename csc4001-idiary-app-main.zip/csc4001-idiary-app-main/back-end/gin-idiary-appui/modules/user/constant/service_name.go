/*
 * @Author: liziwei01
 * @Date: 2022-03-03 16:16:57
 * @LastEditors: liziwei01
 * @LastEditTime: 2022-04-16 17:33:55
 * @Description: file content
 */

package constant

const (
	// db service conf name
	SERVICE_CONF_DB_IDIARY_USER = "db_idiary_user"
)
