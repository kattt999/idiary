/*
 * @Author: liziwei01
 * @Date: 2022-04-18 17:27:34
 * @LastEditors: liziwei01
 * @LastEditTime: 2022-04-18 20:48:39
 * @Description: file content
 */
package data

// import (
// 	"context"
// 	infoDao "gin-idiary-appui/modules/user/dao/info"
// 	userModel "gin-idiary-appui/modules/user/model"
// )

// func CheckPassword(ctx context.Context, pars userModel.LoginPars) (bool, error) {
// 	info, err := infoDao.GetUserInfoByEmail(ctx, pars.Email)
// 	if err != nil {
// 		return false, err
// 	}
// 	return info, nil
// }
