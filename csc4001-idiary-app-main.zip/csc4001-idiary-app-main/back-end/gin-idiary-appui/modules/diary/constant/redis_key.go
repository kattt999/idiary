/*
 * @Author: liziwei01
 * @Date: 2022-04-24 20:44:20
 * @LastEditors: liziwei01
 * @LastEditTime: 2022-04-24 21:11:11
 * @Description: file content
 */
/*
 * @Author: liziwei01
 * @Date: 2022-04-12 13:17:07
 * @LastEditors: liziwei01
 * @LastEditTime: 2022-04-12 14:03:36
 * @Description: file content
 */
package constant

const (
	// 用户给日记点赞 key
	CACHED_USER_LIKE_DIARY = "str:user:%d:like:%d"
	// 日记点赞数 key
	CACHED_DIARY_LIKED_COUNT = "int:diary:%d:liked"
)
