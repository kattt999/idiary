/*
 * @Author: liziwei01
 * @Date: 2022-04-12 13:17:33
 * @LastEditors: liziwei01
 * @LastEditTime: 2022-04-16 18:39:33
 * @Description: file content
 */
package constant

const (
	// db service conf name
	SERVICE_CONF_DB_IDIARY_FEED = "db_idiary_feed"
	
	SERVICE_CONF_DB_IDIARY_USER = "db_idiary_user"

	// redis service conf name
	SERVICE_CONF_REDIS_IDIARY = "redis_idiary_cache"
)
